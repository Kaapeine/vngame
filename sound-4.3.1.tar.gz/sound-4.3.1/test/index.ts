import { suite } from './suite';

suite();
suite(true);
